package com.example.ebookstore_consumer_feign_resilience4J;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreConsumerFeignResilience4JApplicationTests {

	@Test
	void contextLoads() {
	}

}
