package com.example.ebookstore_consumer_feign_resilience4J.proxy;
import java.util.Collections;
import java.util.List;
 
import org.springframework.stereotype.Component;

import com.example.ebookstore_consumer_feign_resilience4J.proxy.BookServiceProxy;
 

 
@Component
public class BookServiceFallback implements BookServiceProxy {
 
    @Override
    public Object getBookById(Integer id) {
        // Provide a default response, e.g., a default book object or a message
        return "Fallback: Book with ID " + id + " is not available.";
    }
 
    @Override
    public List<Object> getAllBooks() {
        // Return an empty list or a default message
        return Collections.emptyList(); // or provide a default list of books
    }
}