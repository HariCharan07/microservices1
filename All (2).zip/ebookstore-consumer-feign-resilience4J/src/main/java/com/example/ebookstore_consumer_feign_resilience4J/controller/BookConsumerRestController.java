package com.example.ebookstore_consumer_feign_resilience4J.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.ebookstore_consumer_feign_resilience4J.proxy.BookServiceProxy;

import java.util.List;

@RestController
public class BookConsumerRestController {

    @Autowired
    private BookServiceProxy bookServiceProxy;

    @GetMapping("/")
    public List<Object> getAllBooks() {
        return bookServiceProxy.getAllBooks();
    }

    @GetMapping("/{id}")
    public Object getBookById(@PathVariable("id") Integer id) {
        return bookServiceProxy.getBookById(id);
    }
}