package com.example.ebookstore_consumer_feign_resilience4J.proxy;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



import java.util.List;

@FeignClient(name = "book-service" ,fallback=BookServiceFallback.class)
public interface BookServiceProxy {

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Object  getBookById(@PathVariable("id") Integer id);

    @GetMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Object> getAllBooks();
}


//import java.util.Arrays;
//import java.util.List;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.http.MediaType;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//
//import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
//import io.github.resilience4j.retry.annotation.Retry;
//
//
//@FeignClient(name = "book-service") // Specify fallback class
//public interface BookServiceProxy {
//
//	@Retry(name="book-service")
//	@CircuitBreaker(name="book-service", fallbackMethod="fallBackMethodGetBookById")
//   @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
//   public Object getBookById(@PathVariable("id") Integer id);
//
//	@Retry(name="book-service")
//	@CircuitBreaker(name = "bookService", fallbackMethod = "fallbackMethodGetAllBooks")
//   @GetMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
//   public List<Object> getAllBooks();
//
//   // Default fallback methods
//   default Object fallbackMethodGetBookById(Integer id, Throwable cause) {
//       System.out.println("Exception raised with message: " + cause.getMessage());
//       // Return a default Object, you might want to wrap it in a response model
//       return new Object(); // Replace with a meaningful default if needed
//   }
//
//   default List<Object> fallbackMethodGetAllBooks(Throwable cause) {
//       System.out.println("Exception raised with message: " + cause.getMessage());
//       return Arrays.asList(); // Return an empty list as fallback
//   }
//}