package com.example.ebookstore_consumer_feign_resilience4J;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class EbookstoreConsumerFeignResilience4JApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbookstoreConsumerFeignResilience4JApplication.class, args);
	}

}
