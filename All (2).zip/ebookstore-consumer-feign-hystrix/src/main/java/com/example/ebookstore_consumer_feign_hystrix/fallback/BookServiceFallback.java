package com.example.ebookstore_consumer_feign_hystrix.fallback;
import org.springframework.stereotype.Component;

import com.example.ebookstore_consumer_feign_hystrix.proxy.BookServiceProxy;

import java.util.Collections;
import java.util.List;

@Component
public class BookServiceFallback implements BookServiceProxy {
	@Override
	public Object getBookById(Integer id) {
		return Collections.emptyList();
    }

    @Override
    public List<Object> getAllBooks() {
        // Fallback logic, e.g., returning an empty list
        return Collections.emptyList();
    }
}