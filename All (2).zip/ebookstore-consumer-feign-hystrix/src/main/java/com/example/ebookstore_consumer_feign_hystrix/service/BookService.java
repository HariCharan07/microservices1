package com.example.ebookstore_consumer_feign_hystrix.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ebookstore_consumer_feign_hystrix.proxy.BookServiceProxy;

import java.util.List;

@Service
public class BookService {

    private final BookServiceProxy bookServiceProxy;

    @Autowired
    public BookService(BookServiceProxy bookServiceProxy) {
        this.bookServiceProxy = bookServiceProxy;
    }

    public Object getBookById(Integer id) {
        return bookServiceProxy.getBookById(id);
    }

    public List<Object> getAllBooks() {
        return bookServiceProxy.getAllBooks();
    }
}
