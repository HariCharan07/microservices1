package com.example.ebookstore_consumer_feign_hystrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreConsumerFeignHystrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
