package com.example.ebookstore_consumer_resilience4J;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreConsumerResilience4JApplicationTests {

	@Test
	void contextLoads() {
	}

}
