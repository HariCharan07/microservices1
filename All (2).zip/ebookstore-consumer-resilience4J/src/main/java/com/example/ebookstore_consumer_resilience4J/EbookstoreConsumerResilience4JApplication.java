package com.example.ebookstore_consumer_resilience4J;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbookstoreConsumerResilience4JApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbookstoreConsumerResilience4JApplication.class, args);
	}

}
