package com.example.ebookstore_consumer_resilience4J.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
 
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
 
@Service
public class BookService {
 
    @Autowired
    private RestTemplate restTemplate;
 
    private static final String BOOK_SERVICE_URL = "http://book-service/";
 
    @Retry(name="book-service")
    @CircuitBreaker(name = "book-service", fallbackMethod = "fallbackForGetBookById")
    public Object getBookById(Long id) {
        String url = BOOK_SERVICE_URL + id;  // Construct the URL using the ID
        return restTemplate.getForObject(url, Object.class);
    }
 
    // Fallback method
    public String fallbackForGetBookById(Long id, Throwable throwable) {
        return "Fallback response: Book not found for ID " + id;  // Return a meaningful message
    }
}