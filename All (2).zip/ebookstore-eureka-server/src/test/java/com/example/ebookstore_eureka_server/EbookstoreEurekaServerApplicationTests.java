package com.example.ebookstore_eureka_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
