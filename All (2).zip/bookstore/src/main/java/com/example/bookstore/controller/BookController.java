package com.example.bookstore.controller;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.example.bookstore.entity.Book;
import com.example.bookstore.service.IBookService;

@RestController
@Scope(value = "request")
public class BookController {
    @Autowired
    @Qualifier(value = "bookService")
    private IBookService bookService;
    
    private static final Logger log = LoggerFactory.getLogger(BookController.class);  
    
  
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Book savedBook = bookService.addBook(book);
        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable int id, @RequestBody Book book) {
        Book updatedBook = bookService.updateBook(book);
        return new ResponseEntity<>(updatedBook, HttpStatus.OK);
    }
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
    
    
//    @GetMapping("/{id}")
//    public ResponseEntity<Book> getBookById(@PathVariable int id) {
//        Book book = bookService.getBookById(id);
//        return new ResponseEntity<>(book, HttpStatus.OK);
//    }

   
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") Integer id) {
        log.debug("In getBookById with Id: " + id);
        Book book = bookService.getBookById(id);
        log.debug("In getBookById with return value book: " + book);
        return ResponseEntity.ok(book);
    }
    
//    @GetMapping("/{id}")
//
//    public ResponseEntity<Book> getBookById(@PathVariable int id) {
//
//        log.debug("Fetching Book by ID: {}", id);
//
//        return bookService.getBookById(id)
//
//                .map(book -> {
//
//                    log.debug("Fetched Book: {}", book);
//
//                    return ResponseEntity.ok(book);
//
//                })
//
//                .orElseGet(() -> {
//
//                    log.warn("Book not found for ID: {}", book_id);
//
//                    return ResponseEntity.notFound().build();
//
//                });
//
//    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBookById(@PathVariable int id) {
        bookService.deleteBookById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    @GetMapping("/search/title")
    public ResponseEntity<List<Book>> findByTitle(@RequestParam String title) {
        List<Book> books = bookService.findByTitle(title);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
    @GetMapping("/search/publisher")
    public ResponseEntity<List<Book>> findByPublisher(@RequestParam String publisher) {
        List<Book> books = bookService.findByPublisher(publisher);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
    @GetMapping("/search/year")
    public ResponseEntity<List<Book>> findByYear(@RequestParam int publicationYear) {
        List<Book> books = bookService.findByPublicationYear(publicationYear);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
}