package com.example.bookstore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;


import com.example.bookstore.repo.BookRepository;

import brave.sampler.Sampler;

@SpringBootApplication
@EnableDiscoveryClient
public class BookstoreApplication {

    @Autowired
    @Qualifier(value = "bookRepository")
    private BookRepository bookRepository;

    public static void main(String[] args) {
        SpringApplication.run(BookstoreApplication.class, args);
    }

    @Bean
    Sampler alwaysSampler() { 
        return Sampler.ALWAYS_SAMPLE;
    }
    
   
}



