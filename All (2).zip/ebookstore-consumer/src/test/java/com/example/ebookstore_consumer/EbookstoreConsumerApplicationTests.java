package com.example.ebookstore_consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
