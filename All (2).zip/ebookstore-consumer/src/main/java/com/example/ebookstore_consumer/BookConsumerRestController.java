package com.example.ebookstore_consumer;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.client.RestTemplate;

@RestController

public class BookConsumerRestController {

   @Autowired

   private RestTemplate restTemplate;

   @GetMapping("/get-books/{id}")

   public Object getBookById(@PathVariable("id") Integer id) {

       String url = "http://book-service/"+ id;

       return restTemplate.getForObject(url, Object.class);

   }

}