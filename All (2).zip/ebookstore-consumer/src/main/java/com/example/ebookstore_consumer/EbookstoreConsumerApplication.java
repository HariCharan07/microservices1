package com.example.ebookstore_consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbookstoreConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbookstoreConsumerApplication.class, args);
	}

}
