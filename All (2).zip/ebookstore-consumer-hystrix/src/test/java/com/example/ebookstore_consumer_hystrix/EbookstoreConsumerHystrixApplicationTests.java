package com.example.ebookstore_consumer_hystrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreConsumerHystrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
