package com.example.ebookstore_consumer_feign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreConsumerFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
